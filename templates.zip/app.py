import requests
from bs4 import BeautifulSoup

# URL of the website you want to scrape
url = 'https://learn.rumie.org/AO/bytes/prepare-for-a-specific-job-interview/?msclkid=a3b6f10af78c151d3b2c963c149d9844&utm_source=bing&utm_medium=cpc&utm_campaign=RumieLearn-Bytes%20%28non-NA%29&utm_term=most%20common%20interview%20questions%20answers&utm_content=TS%20-%20Best%20Way%20To%20Answer%20Interview%20Questions'  # Replace with the target URL

# Send a GET request to the website
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the content of the page using BeautifulSoup
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # Find all h1 tags on the page
    h1_tags = soup.find_all('p')
    
    # Print the text content of each h1 tag
    for h1 in h1_tags:
        print(h1.get_text())
else:
    print(f"Failed to retrieve the webpage. Status code: {response.status_code}")
