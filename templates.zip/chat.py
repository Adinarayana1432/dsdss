from flask import Flask, render_template, request, jsonify
import speech_recognition as sr
import os

app = Flask(__name__)

# Function to handle speech recognition
def recognize_speech():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source)  # Adjust for ambient noise
        print("Please say something")
        audio = r.listen(source)  # Listen for the user's speech
        
        print("Received audio")
        
        try:
            # Recognize speech using Google Web Speech API
            recognized_text = r.recognize_google(audio)
            print("You have said: " + recognized_text)
            return recognized_text
        except Exception as e:
            print("Error: " + str(e))
            return "Sorry, I could not recognize the speech."

# Route for the home page
@app.route('/')
def home():
    return render_template('chat.html')

# Route for processing speech recognition
@app.route('/recognize', methods=['POST'])
def recognize():
    recognized_text = recognize_speech()
    return jsonify({'recognized_text': recognized_text})

if __name__ == "__main__":
    app.run(debug=True)
